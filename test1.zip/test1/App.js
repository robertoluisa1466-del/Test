import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  ActivityIndicator,
  Linking,
  StatusBar,
} from 'react-native';

export default function App() {
  const [activeTab, setActiveTab] = useState('trending');
  const [currency, setCurrency] = useState('£');
  const [region, setRegion] = useState('UK');
  const [sortBy, setSortBy] = useState('profit');

  const [query, setQuery] = useState('');
  const [buyPrice, setBuyPrice] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [savedItems, setSavedItems] = useState([]);
  const [trendingItems, setTrendingItems] = useState([]);
  const [timeRemaining, setTimeRemaining] = useState('');

  const PLATFORM_FEES = {
    eBay: 0.13,
    Amazon: 0.15,
    Vinted: 0.0,
    Mercari: 0.1,
  };

  const UK_HOT_PRODUCTS = [
    { id: 'uk-1', name: 'Sony WH-1000XM5 Wireless Headphones', baseBuy: 125.50, baseResale: 240.00, platform: 'eBay', country: 'UK 🇬🇧', minPrice: 110, categoryId: '112529' },
    { id: 'uk-2', name: 'Nike Dunk Low Retro Panda', baseBuy: 55.00, baseResale: 110.00, platform: 'Vinted', country: 'UK 🇬🇧', minPrice: 40 },
    { id: 'uk-3', name: 'PlayStation 5 DualSense Edge Controller', baseBuy: 95.00, baseResale: 160.00, platform: 'Amazon', country: 'UK 🇬🇧', minPrice: 70 },
    { id: 'uk-4', name: 'LEGO Star Wars Millennium Falcon', baseBuy: 90.00, baseResale: 180.00, platform: 'eBay', country: 'UK 🇬🇧', minPrice: 70, categoryId: '19006' },
    { id: 'uk-5', name: 'Nintendo Switch OLED Model', baseBuy: 150.00, baseResale: 240.00, platform: 'eBay', country: 'UK 🇬🇧', minPrice: 110, categoryId: '139971' },
  ];

  const WORLDWIDE_HOT_PRODUCTS = [
    { id: 'ww-1', name: 'Apple iPhone 15 Pro Max 256GB', baseBuy: 750.00, baseResale: 1050.00, platform: 'eBay', country: 'US 🇺🇸', minPrice: 650, categoryId: '9355' },
    { id: 'ww-2', name: 'Steam Deck OLED 512GB', baseBuy: 320.00, baseResale: 520.00, platform: 'Mercari', country: 'US 🇺🇸', minPrice: 250 },
    { id: 'ww-3', name: 'Fujifilm X100V Digital Camera', baseBuy: 1100.00, baseResale: 1650.00, platform: 'eBay', country: 'Japan 🇯🇵', minPrice: 900, categoryId: '31388' },
    { id: 'ww-4', name: 'Pokemon Scarlet & Violet Booster Box', baseBuy: 90.00, baseResale: 160.00, platform: 'Mercari', country: 'Japan 🇯🇵', minPrice: 70 },
    { id: 'ww-5', name: 'Meta Quest 3 128GB VR Headset', baseBuy: 310.00, baseResale: 460.00, platform: 'Amazon', country: 'Germany 🇩🇪', minPrice: 240 },
    { id: 'ww-6', name: 'Travis Scott x Air Jordan 1 Low', baseBuy: 420.00, baseResale: 780.00, platform: 'eBay', country: 'US 🇺🇸', minPrice: 350, categoryId: '15709' },
  ];

  const openProductUrl = (productName, platform) => {
    const isUK = region === 'UK';
    let url = '';

    if (platform === 'eBay') {
      const cleanQuery = `${productName} -headband -parts -repair -replacement -case -broken -only -cables -earpads`;
      const domain = isUK ? 'www.ebay.co.uk' : 'www.ebay.com';
      url = `https://${domain}/sch/i.html?_nkw=${encodeURIComponent(cleanQuery)}&LH_BIN=1&_sop=15`;
    } else if (platform === 'Amazon') {
      const domain = isUK ? 'www.amazon.co.uk' : 'www.amazon.com';
      url = `https://${domain}/s?k=${encodeURIComponent(productName)}`;
    } else if (platform === 'Vinted') {
      const domain = isUK ? 'www.vinted.co.uk' : 'www.vinted.com';
      url = `https://${domain}/catalog?search_text=${encodeURIComponent(productName)}`;
    } else {
      url = `https://www.mercari.com/search/?keyword=${encodeURIComponent(productName)}`;
    }

    Linking.openURL(url).catch((err) => console.error('Failed to open URL:', err));
  };

  const formatItem = (item) => {
    const currentBuy = item.baseBuy;
    const currentResale = item.baseResale;
    const feeRate = PLATFORM_FEES[item.platform] || 0.13;
    const platformFee = currentResale * feeRate;
    const netProfit = currentResale - currentBuy - platformFee;
    const roi = (netProfit / currentBuy) * 100;

    return {
      id: item.id,
      productName: item.name,
      platform: item.platform,
      country: item.country,
      buyPrice: currentBuy,
      resalePrice: currentResale,
      netProfit: netProfit,
      roi: roi,
    };
  };

  useEffect(() => {
    const sourceProducts = region === 'UK' ? UK_HOT_PRODUCTS : WORLDWIDE_HOT_PRODUCTS;
    let items = sourceProducts.map((item) => formatItem(item));

    if (sortBy === 'profit') items.sort((a, b) => b.netProfit - a.netProfit);
    else if (sortBy === 'roi') items.sort((a, b) => b.roi - a.roi);
    else if (sortBy === 'price') items.sort((a, b) => a.buyPrice - b.buyPrice);

    setTrendingItems(items);
  }, [region, sortBy]);

  useEffect(() => {
    const timerInterval = setInterval(() => {
      const now = new Date();
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);
      const diff = endOfDay - now;

      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / 1000 / 60) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      setTimeRemaining(
        `${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`
      );
    }, 1000);

    return () => clearInterval(timerInterval);
  }, []);

  const handleSearch = () => {
    if (!query || !buyPrice) return;
    setLoading(true);
    setResults(null);

    setTimeout(() => {
      const basePrice = parseFloat(buyPrice);

      const mockData = [
        { id: `${query}-eBay-${Date.now()}`, productName: query, platform: 'eBay', country: region === 'UK' ? 'UK 🇬🇧' : 'US 🇺🇸', buyPrice: basePrice, resalePrice: basePrice * 1.65 },
        { id: `${query}-Amazon-${Date.now()}`, productName: query, platform: 'Amazon', country: region === 'UK' ? 'UK 🇬🇧' : 'US 🇺🇸', buyPrice: basePrice, resalePrice: basePrice * 1.85 },
        { id: `${query}-Vinted-${Date.now()}`, productName: query, platform: 'Vinted', country: region === 'UK' ? 'UK 🇬🇧' : 'France 🇫🇷', buyPrice: basePrice, resalePrice: basePrice * 1.25 },
      ];

      const processedResults = mockData.map((item) => {
        const resale = item.resalePrice;
        const feeRate = PLATFORM_FEES[item.platform];
        const platformFee = resale * feeRate;
        const netProfit = resale - basePrice - platformFee;
        const roi = (netProfit / basePrice) * 100;

        return {
          ...item,
          netProfit: netProfit,
          roi: roi,
          isProfitable: netProfit > 0,
        };
      });

      setResults(processedResults);
      setLoading(false);
    }, 1000);
  };

  const saveItem = (item) => {
    if (savedItems.some((saved) => saved.id === item.id)) return;
    setSavedItems([...savedItems, item]);
  };

  const removeItem = (id) => {
    setSavedItems(savedItems.filter((item) => item.id !== id));
  };

  const getContainerStyle = () => {
    if (activeTab === 'trending') return styles.bgMesh;
    if (activeTab === 'search') return styles.bgCyber;
    if (activeTab === 'saved') return styles.bgGradient;
  };

  return (
    <SafeAreaView style={[styles.mainCanvas, getContainerStyle()]}>
      <StatusBar barStyle="light-content" />

      {activeTab === 'trending' && (
        <>
          <View style={styles.glowTopOrb} />
          <View style={styles.glowBottomOrb} />
        </>
      )}

      {/* Top Header */}
      <View style={styles.topHeader}>
        <View style={styles.regionToggleContainer}>
          <TouchableOpacity
            style={[styles.regionChip, region === 'UK' && styles.activeChip]}
            onPress={() => { setRegion('UK'); setCurrency('£'); }}>
            <Text style={[styles.chipText, region === 'UK' && styles.activeChipText]}>🇬🇧 UK Deals</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.regionChip, region === 'Worldwide' && styles.activeChip]}
            onPress={() => { setRegion('Worldwide'); setCurrency('$'); }}>
            <Text style={[styles.chipText, region === 'Worldwide' && styles.activeChipText]}>🌐 Worldwide</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity 
          style={styles.currencyToggle}
          onPress={() => setCurrency(currency === '£' ? '$' : '£')}>
          <Text style={styles.currencyText}>{currency}</Text>
        </TouchableOpacity>
      </View>

      {/* Navigation Bar */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'trending' && styles.activeTabButton]}
          onPress={() => setActiveTab('trending')}>
          <Text style={[styles.tabButtonText, activeTab === 'trending' && styles.activeTabButtonText]}>
            🔥 Hot Deals
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'search' && styles.activeTabButton]}
          onPress={() => setActiveTab('search')}>
          <Text style={[styles.tabButtonText, activeTab === 'search' && styles.activeTabButtonTextSearch]}>
            ⚡ Search
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'saved' && styles.activeTabButtonSaved]}
          onPress={() => setActiveTab('saved')}>
          <Text style={[styles.tabButtonText, activeTab === 'saved' && styles.activeTabButtonTextSaved]}>
            ⭐ Saved ({savedItems.length})
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* SECTION 1: HOT DEALS */}
        {activeTab === 'trending' && (
          <View>
            <View style={styles.scannerHeader}>
              <Text style={styles.mainTitle}>Hot Deals ({region === 'UK' ? 'UK Market' : 'Worldwide Market'})</Text>
              <View style={styles.timerBadge}>
                <View style={styles.liveDot} />
                <Text style={styles.timerText}>Resets in: {timeRemaining || '24:00:00'}</Text>
              </View>
            </View>

            <View style={styles.filterContainer}>
              <Text style={styles.filterLabel}>Sort:</Text>
              <TouchableOpacity
                style={[styles.filterChip, sortBy === 'profit' && styles.activeFilterChip]}
                onPress={() => setSortBy('profit')}>
                <Text style={[styles.filterChipText, sortBy === 'profit' && styles.activeFilterChipText]}>
                  💰 Profit
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.filterChip, sortBy === 'roi' && styles.activeFilterChip]}
                onPress={() => setSortBy('roi')}>
                <Text style={[styles.filterChipText, sortBy === 'roi' && styles.activeFilterChipText]}>
                  📈 ROI %
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.filterChip, sortBy === 'price' && styles.activeFilterChip]}
                onPress={() => setSortBy('price')}>
                <Text style={[styles.filterChipText, sortBy === 'price' && styles.activeFilterChipText]}>
                  🏷️ Buy Price
                </Text>
              </TouchableOpacity>
            </View>

            {trendingItems.map((item, index) => {
              const isSaved = savedItems.some((saved) => saved.id === item.id);
              return (
                <View key={item.id} style={styles.glassCardMesh}>
                  <View style={styles.cardHeader}>
                    <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                      <Text style={styles.rankBadge}>#{index + 1}</Text>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.productTitle}>{item.productName}</Text>
                        <Text style={styles.productSubtitle}>{item.platform} • Location: {item.country}</Text>
                      </View>
                    </View>
                    <Text style={styles.profitBadge}>
                      +{currency}{item.netProfit.toFixed(2)}
                    </Text>
                  </View>

                  <View style={styles.cardDetails}>
                    <Text style={styles.detailText}>Avg Buy: {currency}{item.buyPrice.toFixed(2)}</Text>
                    <Text style={styles.detailText}>Resale: {currency}{item.resalePrice.toFixed(2)}</Text>
                    <Text style={styles.detailText}>ROI: {item.roi.toFixed(0)}%</Text>
                  </View>

                  <View style={styles.actionRow}>
                    <TouchableOpacity
                      style={styles.linkButton}
                      onPress={() => openProductUrl(item.productName, item.platform)}>
                      <Text style={styles.linkButtonText}>🔗 View on {item.platform}</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={[styles.saveButton, isSaved && styles.saveButtonDisabled]}
                      disabled={isSaved}
                      onPress={() => saveItem(item)}>
                      <Text style={styles.saveButtonText}>
                        {isSaved ? 'Saved' : '+ Save'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* SECTION 2: SEARCH */}
        {activeTab === 'search' && (
          <View>
            <Text style={styles.mainTitleCyber}>⚡ Live Cyber Scanner</Text>

            <View style={styles.cyberCard}>
              <Text style={styles.cyberInputLabel}>PRODUCT / BARCODE</Text>
              <TextInput
                style={styles.cyberInput}
                placeholder="e.g. Nike Air Max, PS5 Controller"
                placeholderTextColor="#475569"
                value={query}
                onChangeText={setQuery}
              />

              <Text style={styles.cyberInputLabel}>BUY PRICE ({currency})</Text>
              <TextInput
                style={styles.cyberInput}
                placeholder="e.g. 25.00"
                placeholderTextColor="#475569"
                keyboardType="numeric"
                value={buyPrice}
                onChangeText={setBuyPrice}
              />

              <TouchableOpacity style={styles.cyberButton} onPress={handleSearch}>
                <Text style={styles.cyberButtonText}>CALCULATE PROFIT</Text>
              </TouchableOpacity>
            </View>

            {loading && <ActivityIndicator size="large" color="#00FF66" style={{ marginTop: 20 }} />}

            {results && (
              <View style={{ marginTop: 20 }}>
                <Text style={styles.cyberSectionHeader}>RESULTS FOR "{query.toUpperCase()}"</Text>
                {results.map((item) => {
                  const isSaved = savedItems.some((saved) => saved.id === item.id);
                  return (
                    <View key={item.id} style={styles.cyberCard}>
                      <View style={styles.cardHeader}>
                        <View>
                          <Text style={styles.cyberTitle}>{item.platform}</Text>
                          <Text style={styles.productSubtitle}>Origin: {item.country}</Text>
                        </View>
                        <Text style={item.isProfitable ? styles.cyberProfitBadge : styles.cyberLossBadge}>
                          {item.isProfitable ? `+${currency}${item.netProfit.toFixed(2)}` : `-${currency}${Math.abs(item.netProfit).toFixed(2)}`}
                        </Text>
                      </View>

                      <View style={styles.cardDetails}>
                        <Text style={styles.cyberDetailText}>Buy: {currency}{item.buyPrice.toFixed(2)}</Text>
                        <Text style={styles.cyberDetailText}>Resale: {currency}{item.resalePrice.toFixed(2)}</Text>
                        <Text style={styles.cyberDetailText}>ROI: {item.roi.toFixed(0)}%</Text>
                      </View>

                      <View style={styles.actionRow}>
                        <TouchableOpacity
                          style={styles.cyberLinkButton}
                          onPress={() => openProductUrl(item.productName, item.platform)}>
                          <Text style={styles.cyberLinkText}>🔗 Open {item.platform}</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                          style={[styles.cyberSaveButton, isSaved && styles.saveButtonDisabled]}
                          disabled={isSaved}
                          onPress={() => saveItem(item)}>
                          <Text style={styles.cyberSaveText}>{isSaved ? 'Saved' : '+ Save'}</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  );
                })}
              </View>
            )}
          </View>
        )}

        {/* SECTION 3: SAVED */}
        {activeTab === 'saved' && (
          <View>
            <Text style={styles.mainTitleRoyal}>⭐ Saved Vault</Text>
            {savedItems.length === 0 ? (
              <View style={styles.emptyContainer}>
                <Text style={styles.emptyTextRoyal}>
                  Your vault is empty. Save deals from Hot Deals or Search to track them here!
                </Text>
              </View>
            ) : (
              savedItems.map((item) => (
                <View key={item.id} style={styles.royalCard}>
                  <View style={styles.cardHeader}>
                    <View>
                      <Text style={styles.productTitle}>{item.productName}</Text>
                      <Text style={styles.royalSubtitle}>{item.platform} • {item.country}</Text>
                    </View>
                    <Text style={styles.royalProfitBadge}>
                      +{currency}{item.netProfit.toFixed(2)}
                    </Text>
                  </View>

                  <View style={styles.cardDetails}>
                    <Text style={styles.royalDetailText}>Buy: {currency}{item.buyPrice.toFixed(2)}</Text>
                    <Text style={styles.royalDetailText}>Resale: {currency}{item.resalePrice.toFixed(2)}</Text>
                    <Text style={styles.royalDetailText}>ROI: {item.roi.toFixed(0)}%</Text>
                  </View>

                  <View style={styles.actionRow}>
                    <TouchableOpacity
                      style={styles.royalLinkButton}
                      onPress={() => openProductUrl(item.productName, item.platform)}>
                      <Text style={styles.royalLinkText}>🔗 View Item</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.removeButton} onPress={() => removeItem(item.id)}>
                      <Text style={styles.removeButtonText}>Remove</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))
            )}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  mainCanvas: { flex: 1, position: 'relative' },

  bgMesh: { backgroundColor: '#0B0F19' },
  bgCyber: { backgroundColor: '#05070A', borderTopWidth: 2, borderTopColor: '#00FF66' },
  bgGradient: { backgroundColor: '#1E1B4B' },

  glowTopOrb: { position: 'absolute', top: -90, right: -80, width: 260, height: 260, borderRadius: 130, backgroundColor: 'rgba(0, 122, 255, 0.22)' },
  glowBottomOrb: { position: 'absolute', bottom: -90, left: -80, width: 260, height: 260, borderRadius: 130, backgroundColor: 'rgba(255, 149, 0, 0.18)' },

  topHeader: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 8, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: 'rgba(255, 255, 255, 0.08)' },
  regionToggleContainer: { flexDirection: 'row', gap: 6 },
  regionChip: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 14, backgroundColor: 'rgba(255, 255, 255, 0.08)' },
  activeChip: { backgroundColor: '#007AFF' },
  chipText: { fontSize: 12, fontWeight: 'bold', color: '#94A3B8' },
  activeChipText: { color: '#FFFFFF' },
  currencyToggle: { backgroundColor: 'rgba(0, 122, 255, 0.2)', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, borderWidth: 1, borderColor: 'rgba(0, 122, 255, 0.4)' },
  currencyText: { fontSize: 13, fontWeight: 'bold', color: '#38BDF8' },

  tabBar: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: 'rgba(255, 255, 255, 0.08)' },
  tabButton: { flex: 1, paddingVertical: 14, alignItems: 'center' },
  activeTabButton: { borderBottomWidth: 3, borderBottomColor: '#007AFF' },
  activeTabButtonTextSearch: { color: '#00FF66' },
  activeTabButtonSaved: { borderBottomWidth: 3, borderBottomColor: '#818CF8' },
  activeTabButtonTextSaved: { color: '#A5B4FC' },
  tabButtonText: { fontSize: 13, fontWeight: '600', color: '#64748B' },
  activeTabButtonText: { color: '#38BDF8' },
  scrollContent: { padding: 16 },

  scannerHeader: { alignItems: 'center', marginBottom: 12 },
  mainTitle: { fontSize: 20, fontWeight: 'bold', textAlign: 'center', marginVertical: 10, color: '#F8FAFC' },
  timerBadge: { flexDirection: 'row', alignItems: 'center', marginTop: 4, backgroundColor: 'rgba(239, 68, 68, 0.15)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, borderWidth: 1, borderColor: 'rgba(239, 68, 68, 0.3)' },
  liveDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#EF4444', marginRight: 6 },
  timerText: { fontSize: 12, color: '#FCA5A5', fontWeight: 'bold' },
  filterContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 6 },
  filterLabel: { fontSize: 12, fontWeight: 'bold', color: '#94A3B8', marginRight: 4 },
  filterChip: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 14, backgroundColor: 'rgba(255, 255, 255, 0.05)', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.1)' },
  activeFilterChip: { backgroundColor: 'rgba(0, 122, 255, 0.25)', borderColor: '#007AFF' },
  filterChipText: { fontSize: 11, fontWeight: '600', color: '#94A3B8' },
  activeFilterChipText: { color: '#38BDF8' },
  glassCardMesh: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 14, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.1)' },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  rankBadge: { fontSize: 13, fontWeight: 'bold', color: '#38BDF8', marginRight: 8, backgroundColor: 'rgba(0, 122, 255, 0.2)', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  productTitle: { fontSize: 14, fontWeight: 'bold', color: '#F8FAFC' },
  productSubtitle: { fontSize: 11, color: '#64748B', marginTop: 2 },
  profitBadge: { fontWeight: 'bold', fontSize: 12, color: '#22C55E', backgroundColor: 'rgba(34, 197, 94, 0.15)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, borderWidth: 1, borderColor: 'rgba(34, 197, 94, 0.3)' },
  cardDetails: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 8 },
  detailText: { fontSize: 12, color: '#94A3B8' },
  actionRow: { flexDirection: 'row', gap: 8, marginTop: 4 },
  linkButton: { flex: 1, backgroundColor: 'rgba(0, 122, 255, 0.15)', paddingVertical: 8, borderRadius: 8, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(0, 122, 255, 0.3)' },
  linkButtonText: { color: '#38BDF8', fontWeight: '600', fontSize: 12 },
  saveButton: { flex: 1, backgroundColor: 'rgba(255, 255, 255, 0.08)', paddingVertical: 8, borderRadius: 8, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.15)' },
  saveButtonDisabled: { backgroundColor: 'rgba(255, 255, 255, 0.02)', borderColor: 'transparent' },
  saveButtonText: { color: '#F8FAFC', fontWeight: '600', fontSize: 12 },

  mainTitleCyber: { fontSize: 20, fontWeight: '800', textAlign: 'center', marginVertical: 10, color: '#00FF66', letterSpacing: 1 },
  cyberCard: { backgroundColor: '#10141D', borderRadius: 12, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(0, 255, 102, 0.3)' },
  cyberInputLabel: { fontSize: 11, fontWeight: '800', color: '#00FF66', marginBottom: 6, letterSpacing: 1 },
  cyberInput: { backgroundColor: '#05070A', borderWidth: 1, borderColor: 'rgba(0, 255, 102, 0.2)', borderRadius: 8, padding: 10, marginBottom: 14, fontSize: 14, color: '#00FF66' },
  cyberButton: { backgroundColor: '#00FF66', borderRadius: 8, padding: 12, alignItems: 'center' },
  cyberButtonText: { color: '#05070A', fontWeight: '900', fontSize: 14, letterSpacing: 1 },
  cyberSectionHeader: { fontSize: 13, fontWeight: '800', color: '#00FF66', marginBottom: 12, letterSpacing: 1 },
  cyberTitle: { fontSize: 15, fontWeight: 'bold', color: '#00FF66' },
  cyberProfitBadge: { fontWeight: 'bold', fontSize: 12, color: '#00FF66', backgroundColor: 'rgba(0, 255, 102, 0.15)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, borderWidth: 1, borderColor: '#00FF66' },
  cyberLossBadge: { fontWeight: 'bold', fontSize: 12, color: '#EF4444', backgroundColor: 'rgba(239, 68, 68, 0.15)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, borderWidth: 1, borderColor: '#EF4444' },
  cyberDetailText: { fontSize: 12, color: '#94A3B8' },
  cyberLinkButton: { flex: 1, backgroundColor: 'rgba(0, 255, 102, 0.1)', paddingVertical: 8, borderRadius: 8, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(0, 255, 102, 0.3)' },
  cyberLinkText: { color: '#00FF66', fontWeight: 'bold', fontSize: 12 },
  cyberSaveButton: { flex: 1, backgroundColor: 'rgba(255, 255, 255, 0.05)', paddingVertical: 8, borderRadius: 8, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)' },
  cyberSaveText: { color: '#F8FAFC', fontWeight: '600', fontSize: 12 },

  mainTitleRoyal: { fontSize: 20, fontWeight: 'bold', textAlign: 'center', marginVertical: 10, color: '#C7D2FE' },
  royalCard: { backgroundColor: 'rgba(30, 27, 75, 0.6)', borderRadius: 14, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(129, 140, 248, 0.3)' },
  royalSubtitle: { fontSize: 11, color: '#A5B4FC', marginTop: 2 },
  royalProfitBadge: { fontWeight: 'bold', fontSize: 12, color: '#34D399', backgroundColor: 'rgba(52, 211, 153, 0.15)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, borderWidth: 1, borderColor: 'rgba(52, 211, 153, 0.3)' },
  royalDetailText: { fontSize: 12, color: '#C7D2FE' },
  royalLinkButton: { flex: 1, backgroundColor: 'rgba(129, 140, 248, 0.2)', paddingVertical: 8, borderRadius: 8, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(129, 140, 248, 0.4)' },
  royalLinkText: { color: '#C7D2FE', fontWeight: '600', fontSize: 12 },
  removeButton: { flex: 1, backgroundColor: 'rgba(239, 68, 68, 0.15)', paddingVertical: 8, borderRadius: 8, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(239, 68, 68, 0.3)' },
  removeButtonText: { color: '#FCA5A5', fontWeight: '600', fontSize: 12 },
  emptyContainer: { padding: 40, alignItems: 'center' },
  emptyTextRoyal: { color: '#A5B4FC', textAlign: 'center', fontSize: 14 },
});
